﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace lab_2._1
{
    class Program
    {
        public static void Show(List<Toy> t)
        {
            var i = 1;

            Console.WriteLine("-------------------------------------------------");
            Console.WriteLine("| № | Name\t| Type\t| Price\t| Q-ty\t| Age\t|");
            Console.WriteLine("-------------------------------------------------");

            foreach (Toy ts in t)
            {
                Console.WriteLine("| " + i++ + " | " + ts.name + "\t| " + ts.type + "\t| " + ts.price + "\t| " + ts.qtt + "\t| " + ts.age1 + " - " + ts.age2 + " |");
                Console.WriteLine("-------------------------------------------------");
            }
        }
        public static void Print(Toy t)
        {
            var i = 1;

            Console.WriteLine("| " + i++ + " | " + t.name + "\t| " + t.type + "\t| " + t.price + "\t| " + t.qtt + "\t| " + t.age1 + " - " + t.age2 + " |");
            Console.WriteLine("-------------------------------------------------");
        }
        public static Toy AddNewStruct()
        {
            Console.WriteLine("Введите название игрушки:");
            string name = Console.ReadLine();

            Console.WriteLine("Введите тип игрушки:");
            string type = Console.ReadLine();

            Console.WriteLine("Введите начальный воз-й диапазон игрушки:");
            int age1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите конечный воз-й диапазон игрушки:");
            int age2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите цену игрушки:");
            double price =  Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Введите кол-во игрушки:");
            int qtt = Convert.ToInt32(Console.ReadLine());

            return new Toy(name, type, age1, age2, price, qtt);
        }
        static void Main(string[] args)
        {
            List<Toy> toys = new List<Toy>();

            string DataDirectory = "data";

            DataDirectory = "C:\\lmao homebwork\\thirdsem\\yavuahahahah\\lab 2.1" + "\\" + DataDirectory;
            DirectoryInfo dd = new DirectoryInfo(DataDirectory);

            if (dd.Exists == false)
                dd.Create();

            Console.WriteLine("Введите имя файла: ");
            string filename = Console.ReadLine();
            filename = DataDirectory + "\\" + filename;

            try
            {
                if (File.Exists(filename))
                {
                    using (Stream stream = File.Open(filename, FileMode.Open))
                    {
                        var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                        toys = (List<Toy>)bformatter.Deserialize(stream);
                    }
                }
            }

            catch (System.IO.EndOfStreamException)
            {
                Console.Clear();
                Console.WriteLine("Ошибка: файла не сущствует!");
                Console.WriteLine("Попробуйте снова:");
                filename = Console.ReadLine();
            }

            int menu;

            do
            {
                Console.Clear();
                Console.WriteLine("Дорбро пожаловать в главное меню!");
                Console.WriteLine("Имя вашего файла: " + filename);
                Console.WriteLine("\n");
                Console.WriteLine("1. Показать содержимое файла;");
                Console.WriteLine("2. Добавить новый элемент;");
                Console.WriteLine("3. Удалить элемент по индексу;");
                Console.WriteLine("4. Изменить элемент по индексу;");
                Console.WriteLine("5. Сортировка списка по цене игрушки;");
                Console.WriteLine("6. Поиск игрушек по возрасту и цене (>=);");
                Console.WriteLine("7. Самая дорогая игрушка по типу;");
                Console.WriteLine("8. Выйти (Котенок обидется! https://twitter.com/sadcatmemes/status/1155643869360480256)!");


                Console.Write("\n" + "Введите команду: ");

                menu = Convert.ToInt32(Console.ReadLine());

                switch (menu)
                {
                    case 1:
                        Console.Clear();
                        Show(toys);

                        Console.ReadKey();
                        break;
                        
                    case 2:
                        Console.Clear();

                        Console.WriteLine("Добавить:");

                        int submenu;

                        Console.WriteLine("1. В начало;");
                        Console.WriteLine("2. В произвольное место;");

                        submenu = Convert.ToInt32(Console.ReadLine());
                        
                        switch(submenu)
                        {
                            case 1:
                                toys.Insert(0, AddNewStruct());
                                break;
                            case 2:
                                Console.WriteLine("Введите индекс:");

                                toys.Insert(Convert.ToInt32(Console.ReadLine()), AddNewStruct());
                                break;
                            default:
                                Console.WriteLine("Ошибка: невенрный ввод!");
                                break;
                        }
                        Console.ReadKey();
                        break;
                        
                    case 3:
                        Console.Clear();

                        Console.WriteLine("Введите индекс:");

                        toys.RemoveAt(Convert.ToInt32(Console.ReadLine()));
                        Console.ReadKey();
                        break;
                        
                    case 4:
                        Console.Clear();

                        Console.WriteLine("Введите индекс:");

                        toys[Convert.ToInt32(Console.ReadLine())] = AddNewStruct();
                        Console.ReadKey();
                        break;
                        
                    case 5:
                        Console.Clear();

                        toys.Sort((x, y)=>x.price.CompareTo(y.price));

                        Console.WriteLine("Список отсортирован!");
                        Console.ReadKey();
                        break;
                        
                    case 6:
                        Console.Clear();

                        Console.WriteLine("Введите возраст:");
                        int age = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("Введите цену:");
                        double price = Convert.ToDouble(Console.ReadLine());

                        Console.Clear();

                        Console.WriteLine("-------------------------------------------------");
                        Console.WriteLine("| № | Name\t| Type\t| Price\t| Q-ty\t| Age\t|");
                        Console.WriteLine("-------------------------------------------------");

                        foreach (var i in toys)
                        {
                            if ((age >= i.age1 && age <= i.age2) && price <= i.price)
                                Print(i);
                        }

                        Console.ReadKey();
                        break;
                        
                    case 7:
                        Console.Clear();

                        Console.WriteLine("Введите тип:");
                        string type = Console.ReadLine();

                        Console.Clear();

                        Console.WriteLine("-------------------------------------------------");
                        Console.WriteLine("| № | Name\t| Type\t| Price\t| Q-ty\t| Age\t|");
                        Console.WriteLine("-------------------------------------------------");

                        double max_price = -1;

                        foreach (var i in toys)
                        {
                            if (i.price > max_price)
                                max_price = i.price;
                        }

                        foreach (var i in toys)
                        {
                            if (i.type == type && i.price == max_price)
                                Print(i);
                        }

                        Console.ReadKey();
                        break;
                }
                if (menu == 8)
                {
                    using (Stream stream = File.Open(filename, FileMode.Create))
                    {
                        var bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();

                        bformatter.Serialize(stream, toys);
                    }
                }
            }
            while (menu != 8);
        }
    }
}
