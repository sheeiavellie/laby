﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_2._1
{
    [Serializable]
    struct Toy
    {
        public string name;
        public string type;
        public int age1;
        public int age2;

        public double price;
        public int qtt;
        
        public Toy(string name, string type, int age1, int age2, double price, int qtt)
        {
            this.name = name;
            this.type = type;
            this.age1 = age1;
            this.age2 = age2;
            this.price = price;
            this.qtt = qtt;
        }
    }
}
