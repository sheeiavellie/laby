﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using lab1._2.classes;

namespace lab1._2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<IPlayable> toys = new List<IPlayable>();

            Videogame vg = new Videogame("Galaga", "Space", 2.50, false);
            toys.Add(vg);

            ConsToy constructor = new ConsToy("Lego", "Star Wars", 2.50, 1000, "easy");
            toys.Add(constructor);

            RailroadToy railroad = new RailroadToy("Thomas tank engine", "Thomas", 5.50, 1500);
            toys.Add(railroad);

            TableTopToy dnd = new TableTopToy("D&D", "D&D", 10.99);
            toys.Add(dnd);

            DollToy doll = new DollToy("Ken", "Barbie", 12.79, "plastic");
            toys.Add(doll);

            int menu;
            do
            {
                Console.Clear();
                Console.WriteLine("Злая программа би лайк: все понятно сразу и без кучи часов поиска ошибок и сидения в гугле");
                Console.WriteLine("\n");
                Console.WriteLine("1. Видеоигра");
                Console.WriteLine("2. Конструктор");
                Console.WriteLine("3. Железная дорога");
                Console.WriteLine("4. Настолка");
                Console.WriteLine("5. Кукла");
                Console.WriteLine("6. Добавить новый объект :(");
                Console.WriteLine("7. Действия с объектом из списка (по номеру) :(");
                Console.WriteLine("8. Выход");
                
                Console.Write("\n" + "Введите команду: ");

                menu = Convert.ToInt32(Console.ReadLine());

                switch (menu)
                {
                    case 1:
                        SubMenu(toys[0].GetID(), toys);
                        break;
                    case 2:
                        SubMenu(toys[1].GetID(), toys);
                        break;
                    case 3:
                        SubMenu(toys[2].GetID(), toys);
                        break;
                    case 4:
                        SubMenu(toys[3].GetID(), toys);
                        break;
                    case 5:
                        SubMenu(toys[4].GetID(), toys);
                        break;
                    case 6:
                        AddNew(toys);
                        break;
                    case 7:
                        Console.Clear();
                        Console.WriteLine("Введите номер объекта из списка");
                        int n = Convert.ToInt32(Console.ReadLine());
                        while (n > toys.Count() - 1)
                        {
                            Console.WriteLine("Элемента с таким индексом не существует, введите индекс снова:");
                            n = Convert.ToInt32(Console.ReadLine());
                        }
                        Console.ReadKey();
                        SubMenu(toys[n].GetID(), toys); //you use id for easy navigation; i use id just for lulz and such; we are not the same
                        break;
                }
                if (menu == 8)
                    break;
            }
            while (menu != 8);
        }

        static void AddNew(List<IPlayable> a)
        {
            int menu;

            Console.Clear();
            Console.WriteLine("Под меню для создания");
            Console.WriteLine("\n");
            Console.WriteLine("1. Видеоигра");
            Console.WriteLine("2. Конструктор");
            Console.WriteLine("3. Железная дорога");
            Console.WriteLine("4. Настолка");
            Console.WriteLine("5. Кукла");

            Console.Write("\n" + "Введите команду: ");

            menu = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите название:");
            string name = Console.ReadLine();
            Console.WriteLine("Введите тему:");
            string theme = Console.ReadLine();
            Console.WriteLine("Введите цену:");
            double price = Convert.ToDouble(Console.ReadLine());

            switch (menu)
            {
                case 1:
                    a.Add(new Videogame(name, theme, price, false));
                    break;
                case 2:
                    Console.WriteLine("Введите кол-во деталей:");
                    int pices = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Введите сложность:");
                    string dif = Console.ReadLine();
                    a.Add(new ConsToy(name, theme, price, pices, dif));
                    break;
                case 3:
                    Console.WriteLine("Введите длину:");
                    int lenght = Convert.ToInt32(Console.ReadLine());
                    a.Add(new RailroadToy(name, theme, price, lenght));
                    break;
                case 4:
                    a.Add(new TableTopToy(name, theme, price));
                    break;
                case 5:
                    Console.WriteLine("Введите материал:");
                    string material = Console.ReadLine();
                    a.Add(new DollToy(name, theme, price, material));
                    break;
            }
        }

        static void SubMenu(string t, List<IPlayable> a)
        {
            int index = 0;

            foreach (var i in a)
            {
                if (i.GetID() == t)
                    break;
                index += 1;
            }

            int menu;
            do
            {
                Console.Clear();
                Console.WriteLine(string.Format("Под меню для {0}", t));
                Console.WriteLine("\n");
                Console.WriteLine("1. Открыть");
                Console.WriteLine("2. Поиграть");
                Console.WriteLine("3. Убрать");
                Console.WriteLine(string.Format("4. {0}", a[index].CustomMethodName()));
                Console.WriteLine("5. Назад в главное меню");

                Console.Write("\n" + "Введите команду: ");

                menu = Convert.ToInt32(Console.ReadLine());

                switch (menu)
                {
                    case 1:
                        a[index].Unpack();
                        Console.ReadKey();
                        break;
                    case 2:
                        a[index].Play();
                        Console.ReadKey();
                        break;
                    case 3:
                        a[index].Remove();
                        Console.ReadKey();
                        break;
                    case 4:
                        a[index].CustomM();
                        Console.ReadKey();
                        break;
                }
                if (menu == 5)
                    break;
            }
            while (menu != 5);
        }
    }
}