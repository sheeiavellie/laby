﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab1._2.classes
{
    interface IPlayable
    {
        string Type();
        string CustomMethodName();
        void Play();
        void Unpack();
        void Remove();
        string GetID();
        void CustomM();
    }
}