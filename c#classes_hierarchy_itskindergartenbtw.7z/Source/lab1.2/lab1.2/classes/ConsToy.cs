﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab1._2.classes
{
    class ConsToy : Toy
    {
        private static int ageBL = 2;
        private static int ageBR = 5;
        private int el;
        private string dif;

        public string Age { get { return $"{ageBL} - {ageBR}"; } }

        public ConsToy(string n, string th, double p, int ele, string d) : base(n, th, p)
        {
            ID = Convert.ToString(id);
            id += 1;

            CustomMethodname = "Add Elements";

            type = "constructor";
            el = ele;
            dif = d;
        }
        public static void AgeM(int a)
        {
            if (a >= ageBL & a <= ageBR)
            {
                Console.WriteLine("Возраст играющего входит в диапазон");
            }
            else
            {
                Console.WriteLine("Возраст играющего не входит в диапазон");
            }
        }
        public override void CustomM()
        {
            el += 10;
            Console.WriteLine("Вы добавили " + 10 + " лишних деталей");
        }
    }
}