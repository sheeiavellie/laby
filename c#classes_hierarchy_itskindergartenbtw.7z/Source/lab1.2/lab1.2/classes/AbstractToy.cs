﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab1._2.classes
{
    abstract class Toy : IPlayable
    {
        protected string type;
        protected string ID;
        protected static int id = 0;
        protected string CustomMethodname;
        protected int toyUnpackFlag = 0;

        private readonly string name;
        private readonly string theme;
        private readonly double price;

        public string Name { get { return name; } }
        public string Theme { get { return theme; } }
        public double Price { get { return price; } }

        protected Toy(string n, string th, double p)
        {
            name = n;
            theme = th;
            price = p;
        }
        public string GetID()
        {
            return ID;
        }
        public override string ToString()
        {
            return ToString("Unpack");
        }
        public string ToString(string fmt)
        {
            if (string.IsNullOrEmpty(fmt))
                fmt = "Unpack";

            switch (fmt.ToUpperInvariant())
            {
                case "UNPACK":
                    return string.Format("Вы открыли коробку с {0}", type);
                case "PLAY":
                    return string.Format("Вы поиграли с {0}", type);
                case "REMOVE":
                    return string.Format("Вы убрали {0}", type);
                default:
                    string msg = string.Format("'{0}' неправильный формат строки", fmt);
                    throw new ArgumentException(msg);
            }
        }
        public string Type()
        {
            return type;
        }
        public string CustomMethodName()
        {
            return CustomMethodname;
        }
        public void Play()
        {
            if (toyUnpackFlag == 1)
                Console.WriteLine(ToString("Play"));
            else
                Console.WriteLine("Вы не открыли коробку!");
        }
        public void Unpack()
        {
            if (toyUnpackFlag == 0)
            {
                toyUnpackFlag = 1;
                Console.WriteLine(ToString("Unpack"));
            }
            else
                Console.WriteLine("Вы уже открыли коробку!");
        }
        public void Remove()
        {
            if (toyUnpackFlag == 1)
                Console.WriteLine(ToString("Remove"));
            else
                Console.WriteLine("Вы не открыли коробку!");
        }
        public virtual void CustomM()
        {
        }
    }
}
