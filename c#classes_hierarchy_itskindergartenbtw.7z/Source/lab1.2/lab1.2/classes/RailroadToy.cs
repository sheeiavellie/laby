﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab1._2.classes
{
    sealed class RailroadToy : Toy
    {
        private readonly int lenght;

        public int Lenght { get { return lenght; } }

        public RailroadToy(string n, string th, double p, int l):base(n, th, p)
        {
            ID = Convert.ToString(id);
            id += 1;

            CustomMethodname = "Choo Choo";

            type = "railroad";
            lenght = l;
        }
        public override void CustomM()
        {
            Console.WriteLine("They're two, they're four, they're six, they're eight");
            Console.WriteLine("Shunting trucks and hauling freights.");
            Console.WriteLine("Red and green and brown and blue,");
            Console.WriteLine("they're the really useful crew.");
            Console.WriteLine("All with different roles to play,");
            Console.WriteLine("round Tidmouth sheds or far away.");
            Console.WriteLine("Down the hills and round the bends,");
            Console.WriteLine("Thomas and his friends.");
            Console.WriteLine("\nДлина дороги: " + lenght + " метров");
        }
    }
}