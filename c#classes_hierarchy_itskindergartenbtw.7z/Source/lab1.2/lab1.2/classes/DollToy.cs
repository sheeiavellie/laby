﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab1._2.classes
{
    class DollToy : Toy
    {
        private readonly string material;

        public string Material { get {return material; } }

        public DollToy(string n, string th, double p, string m) : base(n, th, p)
        {
            ID = Convert.ToString(id);
            id += 1;

            CustomMethodname = "Tea Time";

            type = "doll";
            material = m;
        }
        public override void CustomM()
        {
            Console.WriteLine("Tea time!");
            Console.WriteLine("Материал куклы: " + material);
        }
    }
}