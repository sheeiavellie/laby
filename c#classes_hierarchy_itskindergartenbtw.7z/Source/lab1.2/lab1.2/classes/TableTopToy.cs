﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab1._2.classes
{
    class TableTopToy : Toy
    {
        private Random runNum = new Random();
        private int diceroll;

        public int DiceRoll { get { return diceroll; } }

        public TableTopToy(string n, string th, double p) : base(n, th, p)
        {
            ID = Convert.ToString(id);
            id += 1;

            CustomMethodname = "Check";

            type = "tabletop";
            diceroll = runNum.Next(1, 21);
        }
        public override void CustomM()
        {
            Console.WriteLine("Time for checking, roll the dice!");
            
            if (diceroll >= 10)
            {
                Console.WriteLine("Check passed!");
            }
            else
            {
                Console.WriteLine("Not a good roll man :(");
            }
        }
    }
}