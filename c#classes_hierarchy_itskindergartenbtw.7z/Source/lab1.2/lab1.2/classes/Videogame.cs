﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab1._2.classes
{
    class Videogame : IPlayable
    {
        protected string ID;
        protected static int id = 10;
        protected string type;

        private readonly string name;
        private readonly string theme;
        private readonly double price;
        private readonly bool online;

        public string Data { get { return $"{name}\n{theme}\n{price}\n{online}"; } }


        public Videogame(string n, string t, double p, bool o)
        {
            ID = Convert.ToString(id);
            id += 1;

            name = n;
            theme = t;
            price = p;

            type = "videogame";

            online = o;
        }
        public string Type()
        {
            return type;
        }
        public string CustomMethodName()
        {
            return "Online";
        }
        public void CustomM()
        {
            if (online == false)
                Console.WriteLine("No");
            else
                Console.WriteLine("Yes");
        }
        public void Play()
        {
            Console.WriteLine("e1m1");
        }
        public void Unpack()
        {
            Console.WriteLine("Unpacked");
        }
        public void Remove()
        {
            Console.WriteLine("Removed");
        }
        public string GetID()
        {
            return ID;
        }
    }
}