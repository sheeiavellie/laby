#include <iostream>
#include "graph.cpp"

using namespace std;

int main()
{
    Graph g1;
    int menu, inputFlag = 0;//объявление переменных, создание графа

    do
    {
        system("CLS");
        puts("\t\tWelcome to 1021 line (Big Sadge) program!");
        puts("\t\tPlease select something below:\n");
        puts("1. What was in file");
        puts("2. Number of cities");
        puts("3. Input road system from file");
        puts("4. Output matrix");
        puts("5. Output list");
        puts("6. Path search matrix");
        puts("7. Path search list");
        puts("8. Exit");//Вывод меню

        cin >> menu;

        switch(menu)
        {
            case 1 : g1.FileType(); break;
            case 2 : g1.NumberV(); break;
            case 3 : g1.InputGraph(); inputFlag = 1; break;
            case 4 : 
                {
                    system("CLS");
                    if (inputFlag == 0)
                    {
                        cout << "Error: road system is not entered yet" << endl;
                        system("pause"); 
                    }
                    else
                        g1.GetMatrix();
                    break;
                }
            case 5 : 
                {
                    system("CLS");
                    if (inputFlag == 0)
                    {
                        cout << "Error: road system is not entered yet" << endl;
                        system("pause"); 
                    }
                    else
                        g1.GetList();
                    break;
                }
            case 6 : 
                {
                    system("CLS");
                    if (inputFlag == 0)
                    {
                        cout << "Error: road system is not entered yet" << endl;
                        system("pause"); 
                    }
                    else
                        g1.BFS1();
                    break;
                }
            case 7 : 
                {
                    system("CLS");
                    if (inputFlag == 0)
                    {
                        cout << "Error: road system is not entered yet" << endl;
                        system("pause"); 
                    }
                    else
                        g1.BFS2();
                    break;
                }//Реализация меню
        }
    }
    while (menu != 8);

    if (menu == 8)
        system("CLS");

    return 0;
}