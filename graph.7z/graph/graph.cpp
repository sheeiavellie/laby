#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "list.cpp"

using namespace std;

int charToInt(char c)
{
    return c - '0';
} //функция преобразования числа типа char в число int

class Graph //класс Граф
{
private:
    int vert = 0; //число вершин
    int FileFlag = 2; //флаг файла: 1 - list; 0 - matrix
    List<Vector<int>> list; //список смежности
    int **m; //матрица смежности
public:

    Graph() //Конструктор
    {
        int i, vCount = 0, elementCount = 0;
        string str1, s;
        system("CLS");//объявление переменных

        ifstream file ("input.txt");

        if (!file)
        {
            cout << "File was not opened" << endl;
            return;
        }//Открываем файл

        char *str = new char [512];
        while (!file.eof())
        {
            file.getline(str, 512, '\n');
            vCount++;
        }//Подсчеи чила вершин

        delete str;

        file.seekg(0, ios::beg);

        while (getline(file, str1))
        {
            str1 += ' ';
            for (int i = 0; i < str1.length(); i++)
            {
                if (isdigit(str1[i]))
                    s += str1[i];
                if (!(isdigit(str1[i])))
                {
                    if (s != "")
                        elementCount++;
                    s = "";
                }   
            }
        }//Подсчет количества целых чисел в файле

        if (elementCount == (vCount * vCount))
            FileFlag = 0;
        else
            FileFlag = 1;//Определения типа структуры в файле и установка соответствующего флага

        vert = vCount;

        m = new int* [vCount];
        for (i = 0; i < vCount; i++)
            m[i] = new int[vCount];//Выделение памяти для матрицы смежности
    }

    ~Graph()
    {
    }//деструктор

    int GetVertex()
    {
        return vert;
    }

    int GetFileFlag()
    {
        return FileFlag;
    }//геттеры для флага и числа вершин

    void InputGraph()//Ввод графа из файла
    {
        system("CLS");
        ifstream file ("input.txt");

        if (!file)
        {
            cout << "File was not opened" << endl;
            system("pause");
        }//открываем файл

        int i = 0, j = 0;
        Vector<int> array;

        if (FileFlag == 0)
        {
            while (!file.eof())
            {
                file >> m[i][j];
                if (j == vert-1)
                {
                    i++;
                    j = 0;
                }
                else
                    j++;
            }
        }//Ввод матрицы, если была передана матрица
        else
        {
            string str;
            while(getline(file, str)) 
            {
                istringstream ss(str);
                int num;
                
                while(ss >> num)
                {
                    for (j = 0; j < vert; j++)
                    {
                        if (num == j+1)
                            m[i][j] = 1;
                        else
                        {
                            if (m[i][j] != 1)
                                m[i][j] = 0;
                        }
                    }
                }
                i++;
            }
        }//Ввод матрицы если был передан список

        for (i = 0; i < vert; i++)
        {
            for (j = 0; j < vert; j++)
            {
                if (m[i][j] == 1)
                {
                    array.push_back(j+1);
                }
            }

            if (array.size() == 0)
                array.push_back(0);

            list.push_back(array);
            array.clear();
        }//Ввод списка по уже введенной матрице
        //все вершины хранятся в соответствии с обозначениями графа (т.е. 1 на рисугке - 1 в программе)
        //В списке, если у вершины нет смежных, то записывается 0

        cout << "Road system passed successfully from the file" << endl;//Ввыод сообщения об успешном вводе графа
        system("pause");
    }

    void GetMatrix()
    {
        cout << endl << "Matrix:" << endl << endl;
        int i = 0, j = 0;

        for (i = 0; i < vert; i++)
        {
            for (j = 0; j < vert; j++)
            {
                cout << m[i][j] << ' ';
                if (j == vert-1)
                    cout << endl;
            }
        }
        cout << endl;
        system("pause");
    }//Вывод матрицы

    void GetList()
    {
        cout << endl << "List:" << endl << endl;
        int i, j;

        for (i = 0; i < list.GetSize(); i++)
        {
            for (j = 0; j < list[i].size(); j++)
            {
                if (list[i][j] == 0)
                    cout << '-' << ' ';
                else
                    cout << list[i][j] << ' ';
            }
            cout << endl;
        }
        cout << endl;
        system("pause");
    }//Вывод списка

    void BFS1() //Поиск в ширину
    {
        int closed[vert] = {0};
        for (int i = 0; i < vert; i++)
            closed[i] = -1;
        int initial, final, j = 0;

        puts("Dear Sir please give us some data:\n");
        puts("Enter initial vertex:");
        cin >> initial;
        puts("Enter final vartex:");
        cin >> final;
        puts("Enter closed cities:");

        initial--;
        final--;

        string str;
        cin.clear();
        cin.ignore();
        getline (cin, str);        

        for (int i = 0; i < str.size(); i++)
        {
            if (str[i] != ' ' && str[i] != '\n')
            {
                closed[j] = charToInt(str[i])-1;
                j++;
            }
        }
        str.~basic_string();

        puts("Closed cities:");
        int closedSize = 0;
        for (int i = 0;; i++)
        {
            if (closed[i] == -1)
                break;
            cout << closed[i]+1 << ' ';
            closedSize++;
        }
        if (closedSize == 0)
            cout << "All cities are opened";
            
        for (int i = 0; i < vert; i++)
        {
            if (closed[i] == initial || closed[i] == final)
            {
                cout << "\nError: initial or final vertex are\non the closed list" << endl;
                system("pause");
                return;
                //break;
            }
        } //Ввод начальных значений: начало, конец, закрытые вершины(через пробел). Проверка на соответствие: начало и конец не могут быть закрытыми вершинами

        /*cout << endl;

        for (int i = 0; i < vert; i++)
            cout << closed[i] << ' ';

        cout << endl;*/ //Вывод массива для отладки

        int visited[vert] = {0}, path[vert] = {0}, fv = 0, flag = 0, current, v = 1;
        Queue q; //Объявление переменных

        for (int i = 0; i < vert; i++)
            visited[i] = -1;

        for (int i = 0; i < vert; i++)
            path[i] = -1; //заполнение массивов -1, т.к. для алгоритма поиска номер вершины на рисунке не соответствует используемому: 1 на рисунке - 0 в программе
        visited[0] = initial;
        for (int i = 0; i < vert; i++)
        {
            flag = 0;
            for (int j = 0; j < closedSize; j++)
                if (closed[j] == i)
                {
                    flag = 1;
                    break;
                }
            if (m[initial][i] == 1 && flag == 0)
                q.push(i);
        }
        flag = 0;


        while (q.size() != 0)
        {
            current = q.front();
            q.pop();
            for (int i = 0; i < vert; i++)
            {
                if (visited[i] == current)
                {
                    fv = 1;
                    break;
                }
            }
            if (fv == 0)
            {
                visited[v] = current;
                for (int i = 0; i < vert; i++)
                {
                    flag = 0;
                    for (int j = 0; j < closedSize; j++)
                    {
                        if (closed[j] == i)
                        {
                            flag = 1;
                            break;
                        }
                    }
                    if (m[current][i] == 1 && flag == 0)
                    {
                        path[i] = current;
                        q.push(i);
                    }
                }
                flag = 0;
                if (q.front() == final)
                {
                    visited[v+1] = q.front();
                    break;
                }
                
                v++;
            }
            fv = 0;
        } /*Классическая реализация алгоритма поиска в ширину. Изменения: добавлены проверки, для того, чтобы мы
        не рассматривали закрытые вершины, алгоритм завершается, как только первая смежная вершина в очереди - конечная*/

        /*for (int i = 0; i < vert; i++)
            if (visited[i] != -1)
                cout << endl << visited[i]+1 << ' ';
        */

        /*for (int i = 0; i < vert; i++)
            if (path[i] != -1)
                cout << endl << i << ' ' << path[i]+1 << ' ';
        
        cout << endl << endl;*/

        int p[vert] = {0}, k = 0;
        for (int i = 0; i < vert; i++)
            p[i] = -1;
        
        for (int v = final; v !=-1; v = path[v])
        {
            p[k] = v;
            k++;
        }

        int c;
        for (int i = 0; i < ((vert - closedSize)/2); i++)
        {
            c = p[i];
            p[i] = p[vert - closedSize - 1 - i];
            p[vert - closedSize - 1 - i] = c;
        }

        int pathFlag = 0;
        for (int i = 0; i < vert; i++)
            if (visited[i] == final)
                pathFlag = 1;

        if (pathFlag == 1)
        {
            cout << endl << "Dear Sir this is path you asked for: " << initial + 1 << "->";
            for (size_t i = 0; i < vert - closedSize; i++)
            {
                if (p[i] != -1)
                {
                    if (i == vert - closedSize - 1)
                        cout << p[i] + 1;
                    else
                        cout << p[i] + 1 << "->";
                }
            }
        }
        else
        {
            cout << "Dear Sir there is no path you asked for";
        }
        cout << endl; //Классический вывод пути для поиска в ширину
        system("pause");

    }

    void BFS2() //Поиск в ширину
    {
        int closed[vert] = {0};
        for (int i = 0; i < vert; i++)
            closed[i] = -1;
        int initial, final, j = 0;

        puts("Dear Sir please give us some data:\n");
        puts("Enter initial vertex:");
        cin >> initial;
        puts("Enter final vartex:");
        cin >> final;
        puts("Enter closed cities:");

        initial--;
        final--;

        string str;
        cin.clear();
        cin.ignore();
        getline (cin, str);        

        for (int i = 0; i < str.size(); i++)
        {
            if (str[i] != ' ' && str[i] != '\n')
            {
                closed[j] = charToInt(str[i])-1;
                j++;
            }
        }
        str.~basic_string();

        puts("Closed cities:");
        int closedSize = 0;
        for (int i = 0;; i++)
        {
            if (closed[i] == -1)
                break;
            cout << closed[i]+1 << ' ';
            closedSize++;
        }
        if (closedSize == 0)
            cout << "All cities are opened";
            
        for (int i = 0; i < vert; i++)
        {
            if (closed[i] == initial || closed[i] == final)
            {
                cout << "\nError: initial or final vertex are\non the closed list" << endl;
                system("pause");
                return;
                //break;
            }
        } //Ввод начальных значений: начало, конец, закрытые вершины(через пробел). Проверка на соответствие: начало и конец не могут быть закрытыми вершинами

        /*cout << endl;

        for (int i = 0; i < vert; i++)
            cout << closed[i] << ' ';

        cout << endl;*/ //Вывод массива для отладки

        int visited[vert] = {0}, path[vert] = {0}, fv = 0, flag = 0, current, v = 1, z = 0, fz = 0;
        Queue q; //Объявление переменных

        for (int i = 0; i < vert; i++)
            visited[i] = -1;

        for (int i = 0; i < vert; i++)
            path[i] = -1; //заполнение массивов -1, т.к. для алгоритма поиска номер вершины на рисунке не соответствует используемому: 1 на рисунке - 0 в программе
        visited[0] = initial;
        for (int i = 0; i < list[initial].size(); i++)
        {
            flag = 0;
            for (int j = 0; j < closedSize; j++)
                if (closed[j] == list[initial][i]-1)
                {
                    flag = 1;
                    break;
                }
            if (list[initial][i] != 0 && flag == 0)
                q.push(list[initial][i]-1);
        }
        flag = 0;


        while (q.size() != 0)
        {
            current = q.front();
            q.pop();
            for (int i = 0; i < vert; i++)
            {
                if (visited[i] == current)
                {
                    fv = 1;
                    break;
                }
            }
            if (fv == 0)
            {
                visited[v] = current;
                for (int i = 0; i < list[current].size(); i++)
                {
                    flag = 0;
                    for (int j = 0; j < closedSize; j++)
                    {
                        if (closed[j] == list[current][i]-1)
                        {
                            flag = 1;
                            break;
                        }
                    }
                    if (list[current][i] != 0 && flag == 0)
                    {
                        for (int i = 0; i < vert; i++)
                        {
                            if (path[i] == current)
                                fz = 1;
                        }
                        if (fz == 0)
                        {
                            path[z] = current;
                            z++;
                        }
                        q.push(list[current][i]-1);
                        fz = 0;
                    }
                }
                flag = 0;
                if (q.front() == final)
                {
                    visited[v+1] = q.front();
                    break;
                }
                else
                {
                    if (q.back() == final)
                    {
                        visited[v+1] = q.back();
                        break;
                    }
                }
                v++;
            }
            fv = 0;
        } /*Классическая реализация алгоритма поиска в ширину. Изменения: добавлены проверки, для того, чтобы мы
        не рассматривали закрытые вершины, алгоритм завершается, как только первая смежная вершина в очереди - конечная*/

        /*for (int i = 0; i < vert; i++)
            if (visited[i] != -1)
                cout << endl << visited[i]+1 << ' ';*/
        

        /*for (int i = 0; i < vert; i++)
            if (path[i] != -1)
                cout << endl << i << ' ' << path[i]+1 << ' ';
        
        cout << endl << endl;*/

        int pathFlag = 0;
        for (int i = 0; i < vert; i++)
            if (visited[i] == final)
                pathFlag = 1;

        if (pathFlag == 1)
        {
            cout << endl << "Dear Sir this is path you asked for: " << initial + 1 << "->";
            for (int i = 0; i < vert; i++)
            {
                if (path[i] != -1)
                    cout << path[i]+1 << "->";
            }
            cout << final + 1;
        }
        else
        {
            cout << "Dear Sir there is no path you asked for";
        }
        cout << endl; //Классический вывод пути для поиска в ширину
        system("pause");

    }

    void FileType()
    {
        system("CLS");
        if (FileFlag == 2)
        {
            cout << "Error: road system is not entered yet" << endl;
            system("pause");
        }
        else
        {
            if (FileFlag == 0)
                cout << "Matrix passed in the file" << endl;
            if (FileFlag == 1)
                cout << "List passed in the file" << endl;
            system("pause");
        }
    } //Вывод типа файла

    void NumberV()
    {
        system("CLS");
        if (vert == 0)
        {
            cout << "Error: road system is not entered yet" << endl;
            system("pause");
        }
        else
        {
            cout << "There are " << vert << " cities" << endl;
            system("pause");
        }//Вывод числа вершин
    }
};